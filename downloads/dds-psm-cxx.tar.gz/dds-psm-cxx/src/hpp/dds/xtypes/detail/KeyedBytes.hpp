#ifndef OMG_DDS_XTYPES_DETAIL_KEYEDBYTES_HPP_
#define OMG_DDS_XTYPES_DETAIL_KEYEDBYTES_HPP_

namespace dds { namespace type { namespace builtin { namespace detail {

class KeyedBytes { };

} } } }

#endif /* OMG_DDS_XTYPES_DETAIL_KEYEDBYTES_HPP_ */
