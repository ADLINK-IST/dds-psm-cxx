#ifndef OMG_DDS_XTYPES_DETAIL_KEYEDSTRING_HPP_
#define OMG_DDS_XTYPES_DETAIL_KEYEDSTRING_HPP_

namespace dds { namespace type { namespace builtin { namespace detail {

class KeyedString { };

} } } }

#endif /* OMG_DDS_XTYPES_DETAIL_KEYEDSTRING_HPP_ */
