#ifndef OMG_DDS_PUB_COHERENT_SET_HPP_
#define OMG_DDS_PUB_COHERENT_SET_HPP_

#include <dds/pub/detail/CoherentSet.hpp>

namespace dds { namespace pub { 
    typedef dds::pub::detail::CoherentSet CoherentSet;
} } 


#endif /* OMG_DDS_PUB_COHERENT_SET_HPP_ */
