/*
 * Query.hpp
 *
 *  Created on: Oct 10, 2012
 *      Author: angelo
 */

#ifndef DDS_SUB_DETAIL_QUERY_HPP_
#define DDS_SUB_DETAIL_QUERY_HPP_

#include <foo/bar/sub/Query.hpp>
namespace dds {
   namespace sub {
      namespace detail {
         typedef foo::bar::sub::Query Query;
      }
   }
}


#endif /* DDS_SUB_DETAIL_QUERY_HPP_ */
