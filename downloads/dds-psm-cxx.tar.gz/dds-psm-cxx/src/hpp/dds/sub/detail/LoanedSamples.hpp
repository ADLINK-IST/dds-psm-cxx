#ifndef OMG_SUB_DETAIL_LOANED_SAMPLES_HPP_
#define OMG_SUB_DETAIL_LOANED_SAMPLES_HPP_

#include <dds/sub/TLoanedSamples.hpp>
#include <foo/bar/sub/LoanedSamples.hpp>

namespace dds { namespace sub { namespace detail {
    typedef dds::sub::TLoanedSamples
    class LoanedSamples { };
} } }
#endif /* OMG_SUB_DETAIL_LOANED_SAMPLES_HPP_ */
