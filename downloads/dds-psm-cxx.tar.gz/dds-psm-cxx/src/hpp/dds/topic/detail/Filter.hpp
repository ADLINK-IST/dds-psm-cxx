#ifndef DDS_TOPIC_DETAIL_QUERY_HPP_
#define DDS_TOPIC_DETAIL_QUERY_HPP_

#include <vector>
#include <iterator>

namespace dds { namespace topic { namespace detail {
	class Filter;
    // Vendors should provide implementation.

} } }
#endif /* DDS_TOPIC_DETAIL_QUERY_HPP_ */
