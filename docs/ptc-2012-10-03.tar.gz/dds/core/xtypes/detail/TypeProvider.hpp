#ifndef OMG_DDS_CORE_XTYPES_DETAIL_TYPE_PROVIDER_HPP_
#define OMG_DDS_CORE_XTYPES_DETAIL_TYPE_PROVIDER_HPP_

namespace dds {
  namespace core {
    namespace xtypes {
      namespace detail {
        class TypeProvider {};
      }
    }
  }
}

#endif /* OMG_DDS_CORE_XTYPES_DETAIL_TYPE_PROVIDER_HPP_ */
