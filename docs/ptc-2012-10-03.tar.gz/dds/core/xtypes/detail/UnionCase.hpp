#ifndef  OMG_DDS_CORE_XTYPES_DETAIL_UNION_CASE_HPP_
#define  OMG_DDS_CORE_XTYPES_DETAIL_UNION_CASE_HPP_

namespace dds {
  namespace core {
    namespace xtypes {
      namespace detail {
        template <typename T>
        class UnionCase { };
      }
    }
  }
}

#endif /* OMG_DDS_CORE_XTYPES_DELEGATE_UNION_CASE_HPP_ */
