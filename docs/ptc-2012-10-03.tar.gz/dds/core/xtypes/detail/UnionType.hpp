#ifndef  OMG_DDS_CORE_XTYPES_DETAIL_UNION_TYPE_HPP_
#define  OMG_DDS_CORE_XTYPES_DETAIL_UNION_TYPE_HPP_

namespace dds {
  namespace core {
    namespace xtypes {
      namespace detail {
        template <typename T>
        class UnionType { };
      }
    }
  }
}

#endif /* OMG_DDS_CORE_XTYPES_DETAIL_UNION_TYPE_HPP_ */
