#ifndef OMG_DDS_CORE_XTYPES_DETAIL_TDYNAMICDATA_HPP_
#define OMG_DDS_CORE_XTYPES_DETAIL_TDYNAMICDATA_HPP_

namespace dds {
  namespace code {
    namespace xtypes {
      namespace detail {
        class DynamicData;
      }
    }
  }
}


#endif /* OMG_DDS_CORE_XTYPES_DETAIL_TDYNAMICDATA_HPP_ */
