#ifndef OMG_DDS_CORE_DETAIL_XTYPES_DYNAMIC_TYPE_HPP_
#define OMG_DDS_CORE_DETAIL_XTYPES_DYNAMIC_TYPE_HPP_

namespace dds {
  namespace core {
    namespace xtypes {
      namespace detail {
        class DynamicType { };
      }
    }
  }
}
#endif /* OMG_DDS_CORE_DETAIL_XTYPES_DYNAMIC_TYPE_HPP_ */
