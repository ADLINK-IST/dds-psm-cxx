#ifndef OMG_DDS_CORE_XTYPES_DETAIL_TMEMBER_TYPE_HPP
#define OMG_DDS_CORE_XTYPES_DETAIL_TMEMBER_TYPE_HPP

namespace dds {
  namespace core {
    namespace xtypes {
      namespace detail {
        class MemberType;
      }
    }
  }
}

#endif /* OMG_DDS_CORE_XTYPES_DETAIL_TMEMBER_TYPE_HPP */
