#ifndef OMG_DDS_CORE_CONFORMANCE_HPP_
#define OMG_DDS_CORE_CONFORMANCE_HPP_

#include <dds/core/detail/conformance.hpp>

#endif /* OMG_DDS_CORE_CONFORMANCE_HPP_ */
