#ifndef OMG_DDS_SUB_GENERATION_COUNT_HPP_
#define OMG_DDS_SUB_GENERATION_COUNT_HPP_

#include <dds/sub/detail/GenerationCount.hpp>

namespace dds { namespace sub {
  typedef detail::GenerationCount GenerationCount;
} }

#endif /* OMG_DDS_SUB_GENERATION_COUNT_HPP_ */

