#ifndef OMG_DDS_SUB_QOS_DATA_READER_QOS_HPP_
#define OMG_DDS_SUB_QOS_DATA_READER_QOS_HPP_

#include <dds/sub/qos/detail/DataReaderQos.hpp>

namespace dds { namespace sub { namespace qos { 
  typedef dds::sub::qos::detail::DataReaderQos DataReaderQos;
} } } 


#endif /* OMG_DDS_SUB_QOS_DATA_READER_QOS_HPP_ */
