#ifndef OMG_SUB_DETAIL_LOANED_SAMPLES_HPP_
#define OMG_SUB_DETAIL_LOANED_SAMPLES_HPP_


namespace dds {
  namespace sub {
    namespace detail {
      template <typename T>
      class LoanedSamples { };
    }
  }
}
#endif /* OMG_SUB_DETAIL_LOANED_SAMPLES_HPP_ */
