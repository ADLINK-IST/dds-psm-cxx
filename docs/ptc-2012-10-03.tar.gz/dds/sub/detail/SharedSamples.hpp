#ifndef OMG_SUB_DETAIL_SHARED_SAMPLES_HPP_
#define OMG_SUB_DETAIL_SHARED_SAMPLES_HPP_


namespace dds {
  namespace sub {
    namespace detail {
      template <typename T>
      class SharedSamples { };
    }
  }
}
#endif /* OMG_SUB_DETAIL_SHARED_SAMPLES_HPP_ */
