#ifndef OMG_DDS_SUB_DETAIL_DATA_READER_HPP_
#define OMG_DDS_SUB_DETAIL_DATA_READER_HPP_

// DataReader Delegate implementation goes here.

#endif /* OMG_TDDS_SUB_DETAIL_DATA_READER_HPP_ */
