#ifndef OMG_DDS_SUB_RANK_HPP_
#define OMG_DDS_SUB_RANK_HPP_

#include <dds/sub/detail/Rank.hpp>

namespace dds { namespace sub { 
  typedef detail::Rank Rank;
} } 

#endif /* OMG_DDS_SUB_RANK_HPP_ */


