#ifndef OMG_DDS_DOMAIN_PACKAGE_INCLUDE_HPP_
#define OMG_DDS_DOMAIN_PACKAGE_INCLUDE_HPP_

#include <dds/domain/find.hpp>
#include <dds/domain/discovery.hpp>

#endif /* OMG_DDS_DOMAIN_PACKAGE_INCLUDE_HPP_ */
